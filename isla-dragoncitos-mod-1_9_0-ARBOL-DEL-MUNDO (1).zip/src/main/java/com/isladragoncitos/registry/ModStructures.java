package com.isladragoncitos.registry;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.worldgen.GiantPiece;
import com.isladragoncitos.worldgen.GiantStructure;
import com.isladragoncitos.worldgen.IslaPiece;
import com.isladragoncitos.worldgen.IslaStructure;
import com.isladragoncitos.worldgen.RiderRuinPiece;
import com.isladragoncitos.worldgen.RiderRuinStructure;
import com.isladragoncitos.worldgen.WorldTreePiece;
import com.isladragoncitos.worldgen.WorldTreeStructure;
import com.isladragoncitos.worldgen.lifetree.LifeTreePiece;
import com.isladragoncitos.worldgen.lifetree.LifeTreeStructure;
import com.isladragoncitos.worldgen.massive.MassivePiece;
import com.isladragoncitos.worldgen.massive.MassiveStructure;
import com.mojang.serialization.Codec;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureType;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModStructures {
    public static final DeferredRegister<StructureType<?>> STRUCTURE_TYPES =
            DeferredRegister.create(Registries.STRUCTURE_TYPE, IslaDragoncitosMod.MODID);
    public static final DeferredRegister<StructurePieceType> STRUCTURE_PIECES =
            DeferredRegister.create(Registries.STRUCTURE_PIECE, IslaDragoncitosMod.MODID);

    public static final RegistryObject<StructureType<IslaStructure>> ISLA_TYPE =
            STRUCTURE_TYPES.register("isla", () -> typeOf(IslaStructure.CODEC));

    public static final RegistryObject<StructurePieceType> ISLA_PIECE =
            STRUCTURE_PIECES.register("isla_piece", () -> (StructurePieceType.ContextlessType) IslaPiece::new);

    public static final RegistryObject<StructureType<RiderRuinStructure>> RUIN_TYPE =
            STRUCTURE_TYPES.register("rider_ruin", () -> typeOf(RiderRuinStructure.CODEC));

    public static final RegistryObject<StructureType<LifeTreeStructure>> LIFE_TREE_TYPE =
            STRUCTURE_TYPES.register("life_tree", () -> typeOf(LifeTreeStructure.CODEC));

    public static final RegistryObject<StructurePieceType> LIFE_TREE_PIECE =
            STRUCTURE_PIECES.register("life_tree_piece", () -> (StructurePieceType.ContextlessType) LifeTreePiece::new);

    public static final RegistryObject<StructureType<MassiveStructure>> MASSIVE_TYPE =
            STRUCTURE_TYPES.register("massive", () -> typeOf(MassiveStructure.CODEC));

    public static final RegistryObject<StructurePieceType> MASSIVE_PIECE =
            STRUCTURE_PIECES.register("massive_piece", () -> (StructurePieceType.ContextlessType) MassivePiece::new);

    public static final RegistryObject<StructurePieceType> RUIN_PIECE =
            STRUCTURE_PIECES.register("rider_ruin_piece", () -> (StructurePieceType.ContextlessType) RiderRuinPiece::new);

    public static final RegistryObject<StructureType<WorldTreeStructure>> WORLD_TREE_TYPE =
            STRUCTURE_TYPES.register("world_tree", () -> typeOf(WorldTreeStructure.CODEC));

    public static final RegistryObject<StructurePieceType> WORLD_TREE_PIECE =
            STRUCTURE_PIECES.register("world_tree_piece", () -> (StructurePieceType.ContextlessType) WorldTreePiece::new);

    public static final RegistryObject<StructureType<GiantStructure>> GIANT_TYPE =
            STRUCTURE_TYPES.register("giant", () -> typeOf(GiantStructure.CODEC));

    public static final RegistryObject<StructurePieceType> GIANT_PIECE =
            STRUCTURE_PIECES.register("giant_piece", () -> (StructurePieceType.ContextlessType) GiantPiece::new);

    private ModStructures() {}

    private static <S extends Structure> StructureType<S> typeOf(Codec<S> codec) {
        return () -> codec;
    }
}
