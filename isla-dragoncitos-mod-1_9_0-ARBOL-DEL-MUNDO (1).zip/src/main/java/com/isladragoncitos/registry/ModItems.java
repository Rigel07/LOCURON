package com.isladragoncitos.registry;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.item.AmuletItem;
import com.isladragoncitos.item.ChronosSickleItem;
import com.isladragoncitos.item.DragonArmorMaterial;
import com.isladragoncitos.item.DragonCodexItem;
import com.isladragoncitos.item.DragonCompassItem;
import com.isladragoncitos.item.DragonRiderItem;
import com.isladragoncitos.item.DragonScaleItem;
import com.isladragoncitos.item.DragonStaffItem;
import com.isladragoncitos.item.DraconicManuscriptItem;
import com.isladragoncitos.item.EdulnariItem;
import com.isladragoncitos.item.FortunaCoinItem;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, IslaDragoncitosMod.MODID);

    // --- escamas (0 rosa, 1 verde, 2 azul, 3 roja)
    public static final RegistryObject<Item> PINK_DRAGON_SCALE = ITEMS.register("pink_dragon_scale",
            () -> new DragonScaleItem(0, new Item.Properties()));
    public static final RegistryObject<Item> GREEN_DRAGON_SCALE = ITEMS.register("green_dragon_scale",
            () -> new DragonScaleItem(1, new Item.Properties()));
    public static final RegistryObject<Item> BLUE_DRAGON_SCALE = ITEMS.register("blue_dragon_scale",
            () -> new DragonScaleItem(2, new Item.Properties()));
    public static final RegistryObject<Item> RED_DRAGON_SCALE = ITEMS.register("red_dragon_scale",
            () -> new DragonScaleItem(3, new Item.Properties()));

    // --- amuletos
    public static final RegistryObject<Item> PINK_AMULET = ITEMS.register("pink_dragon_amulet",
            () -> new AmuletItem(new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON),
                    MobEffects.REGENERATION, MobEffects.LUCK, "pink"));
    public static final RegistryObject<Item> GREEN_AMULET = ITEMS.register("green_dragon_amulet",
            () -> new AmuletItem(new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON),
                    MobEffects.MOVEMENT_SPEED, MobEffects.JUMP, "green"));
    public static final RegistryObject<Item> BLUE_AMULET = ITEMS.register("blue_dragon_amulet",
            () -> new AmuletItem(new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON),
                    MobEffects.WATER_BREATHING, MobEffects.DOLPHINS_GRACE, "blue"));
    public static final RegistryObject<Item> RED_AMULET = ITEMS.register("red_dragon_amulet",
            () -> new AmuletItem(new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON),
                    MobEffects.FIRE_RESISTANCE, MobEffects.DIG_SPEED, "red"));

    // --- herramientas del jinete
    public static final RegistryObject<Item> DRAGON_COMPASS = ITEMS.register("dragon_compass",
            () -> new DragonCompassItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> DRAGON_RIDER = ITEMS.register("dragon_rider",
            () -> new DragonRiderItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));
    public static final RegistryObject<Item> DRAGON_STAFF = ITEMS.register("dragon_staff",
            () -> new DragonStaffItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));
    public static final RegistryObject<Item> EDULNARI = ITEMS.register("edulnari",
            () -> new EdulnariItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));

    // --- huevos generadores
    public static final RegistryObject<Item> DRAGONCITO_SPAWN_EGG = ITEMS.register("dragoncito_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.DRAGONCITO, 0xF58FB5, 0xFFD36B, new Item.Properties()));
    public static final RegistryObject<Item> ANCIENT_DRAGON_SPAWN_EGG = ITEMS.register("ancient_dragon_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.ANCIENT_DRAGON, 0x3B2A5E, 0xFF8A2A, new Item.Properties()));
    public static final RegistryObject<Item> WORSHIPPER_SPAWN_EGG = ITEMS.register("worshipper_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.WORSHIPPER, 0x8E1B1B, 0xE8C15A, new Item.Properties()));

    // --- bloques como item
    public static final RegistryObject<Item> DRAGON_STATUE = blockItem("dragon_statue", ModBlocks.DRAGON_STATUE);
    public static final RegistryObject<Item> PINK_SCALE_BLOCK = blockItem("pink_scale_block", ModBlocks.PINK_SCALE_BLOCK);
    public static final RegistryObject<Item> GREEN_SCALE_BLOCK = blockItem("green_scale_block", ModBlocks.GREEN_SCALE_BLOCK);
    public static final RegistryObject<Item> BLUE_SCALE_BLOCK = blockItem("blue_scale_block", ModBlocks.BLUE_SCALE_BLOCK);
    public static final RegistryObject<Item> RED_SCALE_BLOCK = blockItem("red_scale_block", ModBlocks.RED_SCALE_BLOCK);
    public static final RegistryObject<Item> FIRE_EGG = blockItem("fire_dragon_egg", ModBlocks.FIRE_EGG);
    public static final RegistryObject<Item> ICE_EGG = blockItem("ice_dragon_egg", ModBlocks.ICE_EGG);
    public static final RegistryObject<Item> STORM_EGG = blockItem("storm_dragon_egg", ModBlocks.STORM_EGG);
    public static final RegistryObject<Item> WATER_EGG = blockItem("water_dragon_egg", ModBlocks.WATER_EGG);
    public static final RegistryObject<Item> LIFE_TREE_HEART = blockItem("life_tree_heart", ModBlocks.LIFE_TREE_HEART);

    // --- materiales especiales (para crafteos legendarios)
    public static final RegistryObject<Item> DRAGON_ESSENCE = material("dragon_essence", Rarity.UNCOMMON);
    public static final RegistryObject<Item> TIME_SHARD = material("time_shard", Rarity.RARE);
    public static final RegistryObject<Item> COSMIC_DUST = material("cosmic_dust", Rarity.RARE);
    public static final RegistryObject<Item> VOID_CORE = material("void_core", Rarity.EPIC);
    public static final RegistryObject<Item> SOLAR_FLAKE = material("solar_flake", Rarity.RARE);
    public static final RegistryObject<Item> LUNAR_TEAR = material("lunar_tear", Rarity.RARE);

    // --- equipo unico asociado a dragones
    public static final RegistryObject<Item> CHRONOS_SICKLE = ITEMS.register("chronos_sickle",
            () -> new ChronosSickleItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));
    public static final RegistryObject<Item> OMEGA_PLATE = ITEMS.register("omega_plate",
            () -> new ArmorItem(DragonArmorMaterial.OMEGA, ArmorItem.Type.CHESTPLATE,
                    new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant()));
    public static final RegistryObject<Item> PSYCHE_CROWN = ITEMS.register("psyche_crown",
            () -> new ArmorItem(DragonArmorMaterial.PSYCHE, ArmorItem.Type.HELMET,
                    new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));
    public static final RegistryObject<Item> FORTUNA_COIN = ITEMS.register("fortuna_coin",
            () -> new FortunaCoinItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));

    // --- libros y manuscritos
    public static final RegistryObject<Item> DRAGON_CODEX = ITEMS.register("dragon_codex",
            () -> new DragonCodexItem(new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON)));
    public static final RegistryObject<Item> DRACONIC_MANUSCRIPT = ITEMS.register("draconic_manuscript",
            () -> new DraconicManuscriptItem(new Item.Properties().stacksTo(16).rarity(Rarity.RARE)));

    public static final RegistryObject<Item> WORLD_TREE_LEAVES = blockItem("world_tree_leaves", ModBlocks.WORLD_TREE_LEAVES);

    public static final RegistryObject<Item> ELF_SPAWN_EGG = ITEMS.register("elf_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.ELF, 0xF3E6B0, 0x3F8F4A, new Item.Properties()));

    private ModItems() {}

    private static RegistryObject<Item> blockItem(String name, RegistryObject<net.minecraft.world.level.block.Block> block) {
        return ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties()));
    }

    private static RegistryObject<Item> material(String name, Rarity rarity) {
        return ITEMS.register(name, () -> new Item(new Item.Properties().rarity(rarity)));
    }

    /** Escama del color del dragoncito (0 rosa, 1 verde, 2 azul, 3 roja). */
    public static Item scaleFor(int variant) {
        switch (variant) {
            case 1:
                return GREEN_DRAGON_SCALE.get();
            case 2:
                return BLUE_DRAGON_SCALE.get();
            case 3:
                return RED_DRAGON_SCALE.get();
            default:
                return PINK_DRAGON_SCALE.get();
        }
    }
}
