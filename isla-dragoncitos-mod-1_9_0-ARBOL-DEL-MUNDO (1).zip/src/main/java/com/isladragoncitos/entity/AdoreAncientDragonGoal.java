package com.isladragoncitos.entity;

import java.util.EnumSet;
import java.util.List;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.ai.goal.Goal;

/** Los dragoncitos sienten adoracion por los dragones antiguos: se juntan a su alrededor y les lanzan corazones. */
public class AdoreAncientDragonGoal extends Goal {
    private final DragoncitoEntity mob;
    private AncientDragonEntity target;
    private int repath;

    public AdoreAncientDragonGoal(DragoncitoEntity mob) {
        this.mob = mob;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        if (this.mob.isOrderedToSit() || this.mob.level().isClientSide || this.mob.tickCount % 10 != 0) {
            return false;
        }
        List<AncientDragonEntity> dragons = this.mob.level().getEntitiesOfClass(AncientDragonEntity.class,
                this.mob.getBoundingBox().inflate(28.0D));
        AncientDragonEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (AncientDragonEntity dragon : dragons) {
            double d = this.mob.distanceToSqr(dragon);
            if (d < bestDist) {
                bestDist = d;
                best = dragon;
            }
        }
        this.target = best;
        return best != null;
    }

    @Override
    public boolean canContinueToUse() {
        return this.target != null && this.target.isAlive() && !this.mob.isOrderedToSit()
                && this.mob.distanceToSqr(this.target) < 36.0D * 36.0D;
    }

    @Override
    public void stop() {
        this.target = null;
        this.mob.getNavigation().stop();
    }

    @Override
    public void tick() {
        if (this.target == null) {
            return;
        }
        this.mob.getLookControl().setLookAt(this.target, 30.0F, 30.0F);
        double radius = 3.0D + this.target.getVisualScale() * 1.3D;
        double distance = this.mob.distanceTo(this.target);
        if (distance > radius && --this.repath <= 0) {
            this.repath = 10;
            double angle = this.mob.getRandom().nextDouble() * Math.PI * 2.0D;
            double r = radius * 0.8D;
            this.mob.getNavigation().moveTo(this.target.getX() + Math.cos(angle) * r,
                    this.target.getY() + this.target.getBbHeight() * 0.4D + this.mob.getRandom().nextInt(3),
                    this.target.getZ() + Math.sin(angle) * r, 1.3D);
        } else if (distance <= radius) {
            this.mob.getNavigation().stop();
        }
        if (this.mob.tickCount % 25 == 0 && this.mob.level() instanceof ServerLevel level) {
            level.sendParticles(ParticleTypes.HEART, this.mob.getX(), this.mob.getY() + 0.7D, this.mob.getZ(), 1, 0.2D, 0.1D, 0.2D, 0.0D);
        }
    }
}
