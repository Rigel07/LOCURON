package com.isladragoncitos.worldgen.lifetree;

import com.isladragoncitos.abilities.DraconicAbilities;
import com.isladragoncitos.item.DraconicManuscriptItem;
import com.isladragoncitos.registry.ModItems;
import com.isladragoncitos.system.DraconicData;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraftforge.registries.ForgeRegistries;

/** Logica del Arbol de la Vida: Bendicion (Marca Nivel 2, +50 puntos, una habilidad) y botin infinito. */
public final class TreeOfLifeHandler {
    private static final String COOLDOWN_KEY = "tree_of_life";
    private static List<Item> everyItem;

    private TreeOfLifeHandler() {}

    public static void onTouch(ServerPlayer player, BlockPos pos) {
        ServerLevel level = player.serverLevel();
        if (DraconicData.findSharedDragon(player) == null) {
            player.displayClientMessage(Component.literal("\u00a7cA\u00fan no has vinculado tu vida con un drag\u00f3n. El \u00c1rbol de la Vida no te reconoce."), false);
            return;
        }
        if (DraconicData.getMarkLevel(player) < 2) {
            DraconicData.setMarkLevel(player, 2);
            DraconicData.addHalfPoints(player, 100);
            List<String> locked = new ArrayList<>();
            for (String id : DraconicAbilities.ids()) {
                if (!DraconicData.hasAbility(player, id)) {
                    locked.add(id);
                }
            }
            String message = "\u00a7eMarca Nivel 2 activa: vida compartida x2 y +50 puntos";
            if (!locked.isEmpty()) {
                String id = locked.get(level.random.nextInt(locked.size()));
                DraconicData.unlockAbility(player, id);
                message += " \u00a77\u00b7 \u00a76habilidad: \u00a7f" + DraconicAbilities.get(id).nameEs;
            }
            player.displayClientMessage(Component.literal("\u00a76\u00a7l\u00a1BENDICI\u00d3N DEL \u00c1RBOL DE LA VIDA!"), false);
            player.displayClientMessage(Component.literal(message), false);
            level.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, player.getX(), player.getY() + 1.0D, player.getZ(), 120, 0.8D, 1.4D, 0.8D, 0.5D);
            level.playSound(null, pos, SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundSource.PLAYERS, 1.0F, 1.0F);
            DraconicData.grant(player, "tree_of_life");
        } else {
            player.displayClientMessage(Component.literal("\u00a77Ya has recibido la bendici\u00f3n del \u00c1rbol de la Vida."), true);
        }
        long now = level.getGameTime();
        if (DraconicData.getCooldownUntil(player, COOLDOWN_KEY) <= now) {
            DraconicData.setCooldownUntil(player, COOLDOWN_KEY, now + 60L);
            spawnLoot(level, pos.above());
        } else {
            player.displayClientMessage(Component.literal("\u00a77El \u00e1rbol se recupera... (ofrece frutos cada 3 segundos)"), true);
        }
    }

    private static void drop(ServerLevel level, BlockPos pos, ItemStack stack) {
        ItemEntity entity = new ItemEntity(level, pos.getX() + 0.5D, pos.getY() + 0.6D, pos.getZ() + 0.5D, stack);
        entity.setDeltaMovement((level.random.nextDouble() - 0.5D) * 0.2D, 0.25D, (level.random.nextDouble() - 0.5D) * 0.2D);
        level.addFreshEntity(entity);
    }

    /** Botin infinito: manzanas doradas siempre, y de vez en cuando materiales, manuscritos o un objeto al azar. */
    public static void spawnLoot(ServerLevel level, BlockPos pos) {
        drop(level, pos, new ItemStack(Items.GOLDEN_APPLE, 1 + level.random.nextInt(3)));
        float roll = level.random.nextFloat();
        if (roll < 0.03F) {
            drop(level, pos, new ItemStack(Items.ENCHANTED_GOLDEN_APPLE));
        }
        if (level.random.nextFloat() < 0.20F) {
            Item[] materials = {ModItems.DRAGON_ESSENCE.get(), ModItems.COSMIC_DUST.get(), ModItems.TIME_SHARD.get(),
                    ModItems.SOLAR_FLAKE.get(), ModItems.LUNAR_TEAR.get()};
            drop(level, pos, new ItemStack(materials[level.random.nextInt(materials.length)]));
        }
        if (level.random.nextFloat() < 0.06F) {
            List<String> ids = DraconicAbilities.ids();
            drop(level, pos, DraconicManuscriptItem.of(ids.get(level.random.nextInt(ids.size()))));
        }
        if (level.random.nextFloat() < 0.05F) {
            drop(level, pos, new ItemStack(randomItem(level)));
        }
        level.sendParticles(ParticleTypes.HAPPY_VILLAGER, pos.getX() + 0.5D, pos.getY() + 1.0D, pos.getZ() + 0.5D, 16, 0.5D, 0.5D, 0.5D, 0.1D);
    }

    /** Cualquier objeto registrado en el juego (sin los que rompen cosas o no tienen sentido en un cofre). */
    private static Item randomItem(ServerLevel level) {
        if (everyItem == null) {
            everyItem = new ArrayList<>();
            for (Item item : ForgeRegistries.ITEMS.getValues()) {
                String name = String.valueOf(ForgeRegistries.ITEMS.getKey(item));
                if (item == Items.AIR || item instanceof SpawnEggItem || name.contains("command_block") || name.contains("structure_")
                        || name.contains("jigsaw") || name.contains("barrier") || name.contains("debug") || name.contains("light")
                        || name.contains("bedrock") || name.contains("spawner") || name.contains("knowledge_book")
                        || name.contains("end_portal") || name.contains("reinforced_deepslate") || name.contains("petrified")) {
                    continue;
                }
                everyItem.add(item);
            }
        }
        return everyItem.get(level.random.nextInt(everyItem.size()));
    }
}
