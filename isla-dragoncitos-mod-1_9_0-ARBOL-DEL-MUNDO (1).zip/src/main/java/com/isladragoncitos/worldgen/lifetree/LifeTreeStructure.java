package com.isladragoncitos.worldgen.lifetree;

import com.isladragoncitos.registry.ModStructures;
import com.mojang.serialization.Codec;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.NoiseColumn;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureType;

/** El Arbol de la Vida: un arbol colosal con una camara en su base donde late su corazon. */
public class LifeTreeStructure extends Structure {
    public static final Codec<LifeTreeStructure> CODEC = simpleCodec(LifeTreeStructure::new);

    public LifeTreeStructure(Structure.StructureSettings settings) {
        super(settings);
    }

    @Override
    public StructureType<?> type() {
        return ModStructures.LIFE_TREE_TYPE.get();
    }

    private int height(Structure.GenerationContext context, int x, int z) {
        return context.chunkGenerator().getFirstOccupiedHeight(x, z, Heightmap.Types.WORLD_SURFACE_WG, context.heightAccessor(), context.randomState());
    }

    @Override
    protected Optional<Structure.GenerationStub> findGenerationPoint(Structure.GenerationContext context) {
        ChunkPos chunk = context.chunkPos();
        int x = chunk.getMiddleBlockX();
        int z = chunk.getMiddleBlockZ();
        int h = this.height(context, x, z);
        NoiseColumn column = context.chunkGenerator().getBaseColumn(x, z, context.heightAccessor(), context.randomState());
        if (h < 62 || h > 120 || !column.getBlock(h - 1).getFluidState().isEmpty()) {
            return Optional.empty();
        }
        int min = h;
        int max = h;
        int[][] offsets = {{10, 0}, {-10, 0}, {0, 10}, {0, -10}};
        for (int[] offset : offsets) {
            int other = this.height(context, x + offset[0], z + offset[1]);
            min = Math.min(min, other);
            max = Math.max(max, other);
        }
        if (max - min > 7) {
            return Optional.empty();
        }
        long seed = context.random().nextLong();
        int baseY = h;
        return Optional.of(new Structure.GenerationStub(new BlockPos(x, baseY, z),
                builder -> builder.addPiece(new LifeTreePiece(x, baseY, z, seed))));
    }
}
