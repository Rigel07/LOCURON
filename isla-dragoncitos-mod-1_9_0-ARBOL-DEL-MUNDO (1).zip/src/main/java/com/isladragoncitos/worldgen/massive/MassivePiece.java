package com.isladragoncitos.worldgen.massive;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.registry.ModBlocks;
import com.isladragoncitos.registry.ModEntities;
import com.isladragoncitos.registry.ModStructures;
import com.isladragoncitos.entity.DragonWorshipperEntity;
import java.util.Random;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.StructurePiece;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceSerializationContext;

/** Pieza de las estructuras masivas. Todo sale de la semilla, asi que cada chunk reconstruye lo mismo. */
public class MassivePiece extends StructurePiece {
    public static final int CASTLE = 0;
    public static final int CAVE = 1;
    public static final int SANCTUARY = 2;
    public static final int VILLAGE = 3;

    private static final String[] LOOT_NAMES = {"castle", "cave", "sanctuary", "village"};

    private int kind;
    private int cx;
    private int y0;
    private int cz;
    private long seed;

    public MassivePiece(int kind, int cx, int y0, int cz, long seed) {
        super(ModStructures.MASSIVE_PIECE.get(), 0, boxFor(kind, cx, y0, cz));
        this.kind = kind;
        this.cx = cx;
        this.y0 = y0;
        this.cz = cz;
        this.seed = seed;
    }

    public MassivePiece(CompoundTag tag) {
        super(ModStructures.MASSIVE_PIECE.get(), tag);
        this.kind = tag.getInt("Kind");
        this.cx = tag.getInt("Cx");
        this.y0 = tag.getInt("Y0");
        this.cz = tag.getInt("Cz");
        this.seed = tag.getLong("Seed");
    }

    public static int halfSize(int kind) {
        return switch (kind) {
            case CASTLE -> 24;
            case CAVE -> 26;
            case SANCTUARY -> 20;
            default -> 28;
        };
    }

    private static BoundingBox boxFor(int kind, int cx, int y0, int cz) {
        int m = halfSize(kind);
        int down = kind == CAVE ? 28 : 14;
        int up = kind == CASTLE ? 36 : (kind == SANCTUARY ? 26 : 16);
        return new BoundingBox(cx - m, y0 - down, cz - m, cx + m, y0 + up, cz + m);
    }

    @Override
    protected void addAdditionalSaveData(StructurePieceSerializationContext context, CompoundTag tag) {
        tag.putInt("Kind", this.kind);
        tag.putInt("Cx", this.cx);
        tag.putInt("Y0", this.y0);
        tag.putInt("Cz", this.cz);
        tag.putLong("Seed", this.seed);
    }

    private static BlockState b(Block block) {
        return block.defaultBlockState();
    }

    private ResourceLocation loot() {
        return new ResourceLocation(IslaDragoncitosMod.MODID, "chests/" + LOOT_NAMES[this.kind]);
    }

    @Override
    public void postProcess(WorldGenLevel level, StructureManager manager, ChunkGenerator generator, RandomSource random,
                            BoundingBox box, ChunkPos chunkPos, BlockPos pivot) {
        BuildHelper h = new BuildHelper(level, box);
        Random rnd = new Random(this.seed ^ (this.kind * 0x9E3779B97F4A7C15L));
        switch (this.kind) {
            case CASTLE -> this.castle(h, level, box, rnd, random);
            case CAVE -> this.cave(h, level, box, rnd, random);
            case SANCTUARY -> this.sanctuary(h, level, box, rnd, random);
            default -> this.village(h, level, box, rnd, random);
        }
    }

    private BlockState brick(Random rnd) {
        float r = rnd.nextFloat();
        if (r < 0.2F) {
            return b(Blocks.MOSSY_STONE_BRICKS);
        }
        if (r < 0.32F) {
            return b(Blocks.CRACKED_STONE_BRICKS);
        }
        return b(Blocks.STONE_BRICKS);
    }

    private void worshipper(WorldGenLevel level, BoundingBox box, int x, int y, int z, Random rnd) {
        BlockPos pos = new BlockPos(x, y, z);
        if (!box.isInside(pos)) {
            return;
        }
        DragonWorshipperEntity entity = ModEntities.WORSHIPPER.get().create(level.getLevel());
        if (entity == null) {
            return;
        }
        entity.moveTo(x + 0.5D, y, z + 0.5D, rnd.nextFloat() * 360.0F, 0.0F);
        entity.setPersistenceRequired();
        entity.finalizeSpawn(level, level.getCurrentDifficultyAt(pos), MobSpawnType.STRUCTURE, null, null);
        level.addFreshEntityWithPassengers(entity);
    }

    // ---------------------------------------------------------------- castillo

    private void castle(BuildHelper h, WorldGenLevel level, BoundingBox box, Random rnd, RandomSource random) {
        int cx = this.cx;
        int cz = this.cz;
        int y0 = this.y0;
        for (int dx = -22; dx <= 22; dx++) {
            for (int dz = -22; dz <= 22; dz++) {
                h.foundation(cx + dx, cz + dz, y0, 14, b(Blocks.STONE_BRICKS));
            }
        }
        // patio
        for (int dx = -17; dx <= 17; dx++) {
            for (int dz = -17; dz <= 17; dz++) {
                h.set(cx + dx, y0 - 1, cz + dz, (dx + dz) % 4 == 0 ? b(Blocks.POLISHED_ANDESITE) : b(Blocks.COBBLESTONE));
            }
        }
        for (int dz = 8; dz <= 20; dz++) {
            for (int dx = -1; dx <= 1; dx++) {
                h.set(cx + dx, y0 - 1, cz + dz, b(Blocks.SMOOTH_STONE));
            }
        }
        // murallas
        for (int d = -20; d <= 20; d++) {
            for (int t = 0; t < 3; t++) {
                for (int y = 0; y <= 9; y++) {
                    h.set(cx + d, y0 + y, cz - 20 + t, this.brick(rnd));
                    h.set(cx + d, y0 + y, cz + 20 - t, this.brick(rnd));
                    h.set(cx - 20 + t, y0 + y, cz + d, this.brick(rnd));
                    h.set(cx + 20 - t, y0 + y, cz + d, this.brick(rnd));
                }
            }
            if (d % 2 == 0) {
                h.set(cx + d, y0 + 10, cz - 20, b(Blocks.STONE_BRICKS));
                h.set(cx + d, y0 + 10, cz + 20, b(Blocks.STONE_BRICKS));
                h.set(cx - 20, y0 + 10, cz + d, b(Blocks.STONE_BRICKS));
                h.set(cx + 20, y0 + 10, cz + d, b(Blocks.STONE_BRICKS));
            }
        }
        // puerta sur
        h.fill(cx - 2, y0, cz + 18, cx + 2, y0 + 6, cz + 20, BuildHelper.AIR);
        h.fill(cx - 3, y0 + 7, cz + 18, cx + 3, y0 + 7, cz + 20, b(Blocks.DEEPSLATE_BRICKS));
        h.set(cx - 3, y0 + 5, cz + 21, b(Blocks.LANTERN));
        h.set(cx + 3, y0 + 5, cz + 21, b(Blocks.LANTERN));
        // torres de las esquinas
        for (int sx = -1; sx <= 1; sx += 2) {
            for (int sz = -1; sz <= 1; sz += 2) {
                this.tower(h, cx + sx * 20, cz + sz * 20, y0, rnd);
            }
        }
        // torreon central
        for (int dx = -7; dx <= 7; dx++) {
            for (int dz = -7; dz <= 7; dz++) {
                for (int y = 0; y <= 25; y++) {
                    boolean wall = Math.abs(dx) == 7 || Math.abs(dz) == 7;
                    h.set(cx + dx, y0 + y, cz + dz, wall ? this.brick(rnd) : BuildHelper.AIR);
                }
            }
        }
        for (int floor : new int[]{0, 8, 16}) {
            for (int dx = -6; dx <= 6; dx++) {
                for (int dz = -6; dz <= 6; dz++) {
                    if (!(dx == 6 && dz == 0) || floor == 0) {
                        h.set(cx + dx, y0 + floor - (floor == 0 ? 1 : 0), cz + dz, b(Blocks.SPRUCE_PLANKS));
                    }
                }
            }
        }
        for (int dx = -8; dx <= 8; dx++) {
            for (int dz = -8; dz <= 8; dz++) {
                boolean rim = Math.abs(dx) >= 7 || Math.abs(dz) >= 7;
                h.set(cx + dx, y0 + 24, cz + dz, rim ? b(Blocks.DEEPSLATE_TILES) : b(Blocks.SPRUCE_PLANKS));
                if (rim && (dx + dz) % 2 == 0) {
                    h.set(cx + dx, y0 + 25, cz + dz, b(Blocks.DEEPSLATE_TILES));
                }
            }
        }
        h.fill(cx - 1, y0, cz + 7, cx + 1, y0 + 3, cz + 7, BuildHelper.AIR);
        for (int y = 0; y <= 23; y++) {
            h.set(cx + 6, y0 + y, cz, b(Blocks.LADDER).setValue(LadderBlock.FACING, Direction.WEST));
        }
        for (int[] w : new int[][]{{-4, 7}, {0, 7}, {4, 7}, {-4, -7}, {0, -7}, {4, -7}, {7, -4}, {-7, -4}, {-7, 4}, {-7, 0}}) {
            for (int fl : new int[]{3, 11, 19}) {
                h.fill(cx + w[0], y0 + fl, cz + w[1], cx + w[0], y0 + fl + 1, cz + w[1], BuildHelper.AIR);
            }
        }
        for (int fl : new int[]{4, 12, 20}) {
            h.set(cx - 5, y0 + fl, cz - 5, b(Blocks.LANTERN));
            h.set(cx + 5, y0 + fl, cz - 5, b(Blocks.LANTERN));
            h.set(cx - 5, y0 + fl, cz + 5, b(Blocks.LANTERN));
        }
        // sala del trono / altar del huevo
        h.fill(cx - 2, y0 + 17, cz - 5, cx + 2, y0 + 17, cz + 5, b(Blocks.RED_CARPET));
        h.fill(cx - 1, y0 + 17, cz - 1, cx + 1, y0 + 17, cz + 1, b(Blocks.OBSIDIAN));
        h.set(cx, y0 + 18, cz, ModBlocks.egg(rnd.nextInt(3)).defaultBlockState());
        h.lootChest(cx - 5, y0 + 17, cz + 5, this.loot(), random);
        h.lootChest(cx + 5, y0 + 17, cz - 5, this.loot(), random);
        h.lootChest(cx - 5, y0 + 1, cz - 5, this.loot(), random);
        // adoradores
        this.worshipper(level, box, cx, y0, cz + 12, rnd);
        this.worshipper(level, box, cx - 8, y0, cz + 10, rnd);
        this.worshipper(level, box, cx + 9, y0, cz - 10, rnd);
        this.worshipper(level, box, cx, y0 + 9, cz + 2, rnd);
        this.worshipper(level, box, cx + 2, y0 + 17, cz + 3, rnd);
    }

    private void tower(BuildHelper h, int tx, int tz, int y0, Random rnd) {
        for (int dx = -5; dx <= 5; dx++) {
            for (int dz = -5; dz <= 5; dz++) {
                double d2 = dx * dx + dz * dz;
                if (d2 > 26) {
                    continue;
                }
                for (int y = 0; y <= 20; y++) {
                    boolean wall = d2 > 12;
                    h.set(tx + dx, y0 + y, tz + dz, wall ? this.brick(rnd) : BuildHelper.AIR);
                }
                for (int fl : new int[]{0, 7, 14}) {
                    if (!(dx == 3 && dz == 0) || fl == 0) {
                        h.set(tx + dx, y0 + fl - (fl == 0 ? 1 : 0), tz + dz, d2 <= 12 ? b(Blocks.SPRUCE_PLANKS) : b(Blocks.STONE_BRICKS));
                    }
                }
                h.set(tx + dx, y0 + 20, tz + dz, d2 <= 12 ? b(Blocks.SPRUCE_PLANKS) : b(Blocks.DEEPSLATE_TILES));
                if (d2 > 17 && (dx + dz) % 2 == 0) {
                    h.set(tx + dx, y0 + 21, tz + dz, b(Blocks.DEEPSLATE_TILES));
                }
            }
        }
        for (int y = 0; y <= 19; y++) {
            h.set(tx + 3, y0 + y, tz, b(Blocks.LADDER).setValue(LadderBlock.FACING, Direction.WEST));
        }
        for (int fl : new int[]{3, 10, 16}) {
            h.fill(tx + 4, y0 + fl, tz, tx + 4, y0 + fl + 1, tz, BuildHelper.AIR);
            h.fill(tx, y0 + fl, tz - 4, tx, y0 + fl + 1, tz - 4, BuildHelper.AIR);
        }
        h.set(tx, y0 + 6, tz, b(Blocks.LANTERN));
    }

    // ---------------------------------------------------------------- cueva del dragon

    private void cave(BuildHelper h, WorldGenLevel level, BoundingBox box, Random rnd, RandomSource random) {
        int cx = this.cx;
        int cz = this.cz;
        int cy = this.y0 - 14;
        double rx = 20.0D;
        double ry = 11.0D;
        // sala principal
        for (int dx = -21; dx <= 21; dx++) {
            for (int dy = -12; dy <= 12; dy++) {
                for (int dz = -21; dz <= 21; dz++) {
                    double noise = 0.92D + rnd.nextDouble() * 0.16D;
                    double d = (dx * dx) / (rx * rx) + (dy * dy) / (ry * ry) + (dz * dz) / (rx * rx);
                    if (d <= noise) {
                        h.set(cx + dx, cy + dy, cz + dz, BuildHelper.AIR);
                    } else if (d <= 1.35D && h.get(cx + dx, cy + dy, cz + dz).isAir()) {
                        continue;
                    }
                }
            }
        }
        int floorY = cy - 10;
        // suelo oscuro
        for (int dx = -20; dx <= 20; dx++) {
            for (int dz = -20; dz <= 20; dz++) {
                for (int y = floorY - 2; y <= floorY + 1; y++) {
                    if (h.get(cx + dx, y, cz + dz).isAir() && h.get(cx + dx, y - 1, cz + dz).isAir() == false && y <= floorY + 1) {
                        float r = rnd.nextFloat();
                        h.set(cx + dx, y - 1, cz + dz, r < 0.08F ? b(Blocks.MAGMA_BLOCK) : (r < 0.5F ? b(Blocks.BLACKSTONE) : b(Blocks.BASALT)));
                        break;
                    }
                }
            }
        }
        // entrada: tunel que sube a la superficie por el sur
        for (int t = 0; t <= 24; t++) {
            int tz = cz + 10 + t;
            int ty = cy - 8 + (int) Math.round(t * 0.7D);
            for (int dx = -2; dx <= 2; dx++) {
                for (int dy = 0; dy <= 3; dy++) {
                    h.set(cx + dx, ty + dy, tz, BuildHelper.AIR);
                }
            }
            if (t % 5 == 0) {
                h.set(cx - 2, ty + 1, tz, b(Blocks.TORCH));
            }
        }
        // estalactitas y columnas
        for (int i = 0; i < 26; i++) {
            int x = cx + rnd.nextInt(33) - 16;
            int z = cz + rnd.nextInt(33) - 16;
            int len = 3 + rnd.nextInt(6);
            boolean column = rnd.nextInt(4) == 0;
            int top = cy + 9;
            for (int y = 0; y < (column ? 20 : len); y++) {
                h.set(x, top - y, z, b(Blocks.DRIPSTONE_BLOCK));
            }
        }
        // tesoro: montones de oro
        for (int i = 0; i < 7; i++) {
            int px = cx + rnd.nextInt(25) - 12;
            int pz = cz + rnd.nextInt(25) - 12;
            int height = 2 + rnd.nextInt(4);
            for (int dx = -3; dx <= 3; dx++) {
                for (int dz = -3; dz <= 3; dz++) {
                    int hh = height - (int) Math.round(Math.sqrt(dx * dx + dz * dz) * 0.8D);
                    for (int y = 0; y < hh; y++) {
                        float r = rnd.nextFloat();
                        h.set(px + dx, floorY + y, pz + dz, r < 0.3F ? b(Blocks.GOLD_BLOCK) : (r < 0.8F ? b(Blocks.RAW_GOLD_BLOCK) : b(Blocks.EMERALD_BLOCK)));
                    }
                }
            }
        }
        // nido del huevo
        for (int dx = -4; dx <= 4; dx++) {
            for (int dz = -4; dz <= 4; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d <= 4.2D) {
                    h.set(cx + dx, floorY, cz + dz, d >= 3.0D ? b(Blocks.OBSIDIAN) : b(Blocks.GILDED_BLACKSTONE));
                    h.set(cx + dx, floorY + 1, cz + dz, BuildHelper.AIR);
                }
            }
        }
        h.set(cx, floorY + 1, cz, ModBlocks.egg(rnd.nextInt(3)).defaultBlockState());
        for (int[] c : new int[][]{{-3, 0}, {3, 0}, {0, -3}, {0, 3}}) {
            h.set(cx + c[0], floorY + 1, cz + c[1], b(Blocks.SOUL_LANTERN));
        }
        h.lootChest(cx + 6, floorY + 1, cz + 6, this.loot(), random);
        h.lootChest(cx - 7, floorY + 1, cz - 5, this.loot(), random);
        // lava y brillos
        for (int i = 0; i < 4; i++) {
            int lx = cx + rnd.nextInt(29) - 14;
            int lz = cz + rnd.nextInt(29) - 14;
            if (Math.abs(lx - cx) > 6 || Math.abs(lz - cz) > 6) {
                h.fill(lx, floorY, lz, lx + 2, floorY, lz + 2, b(Blocks.LAVA));
            }
        }
        for (int i = 0; i < 40; i++) {
            int x = cx + rnd.nextInt(37) - 18;
            int z = cz + rnd.nextInt(37) - 18;
            h.set(x, cy + 10, z, rnd.nextBoolean() ? b(Blocks.SHROOMLIGHT) : b(Blocks.AMETHYST_CLUSTER).setValue(net.minecraft.world.level.block.AmethystClusterBlock.FACING, Direction.DOWN));
        }
    }

    // ---------------------------------------------------------------- santuario

    private void sanctuary(BuildHelper h, WorldGenLevel level, BoundingBox box, Random rnd, RandomSource random) {
        int cx = this.cx;
        int cz = this.cz;
        int y0 = this.y0;
        for (int dx = -17; dx <= 17; dx++) {
            for (int dz = -17; dz <= 17; dz++) {
                h.foundation(cx + dx, cz + dz, y0, 14, b(Blocks.STONE_BRICKS));
            }
        }
        for (int dx = -16; dx <= 16; dx++) {
            for (int dz = -16; dz <= 16; dz++) {
                h.set(cx + dx, y0 - 1, cz + dz, b(Blocks.SMOOTH_QUARTZ));
                h.set(cx + dx, y0, cz + dz, b(Blocks.SMOOTH_QUARTZ));
                if (Math.abs(dx) <= 13 && Math.abs(dz) <= 13) {
                    h.set(cx + dx, y0 + 1, cz + dz, b(Blocks.QUARTZ_BRICKS));
                }
                if (Math.abs(dx) <= 10 && Math.abs(dz) <= 10) {
                    h.set(cx + dx, y0 + 2, cz + dz, (dx + dz) % 2 == 0 ? b(Blocks.QUARTZ_BLOCK) : b(Blocks.QUARTZ_BRICKS));
                }
            }
        }
        // pilares en anillo
        for (int i = 0; i < 12; i++) {
            double angle = i * Math.PI / 6.0D;
            int px = cx + (int) Math.round(Math.cos(angle) * 9.0D);
            int pz = cz + (int) Math.round(Math.sin(angle) * 9.0D);
            h.set(px, y0 + 3, pz, b(Blocks.CHISELED_QUARTZ_BLOCK));
            for (int y = 4; y <= 12; y++) {
                h.set(px, y0 + y, pz, b(Blocks.QUARTZ_PILLAR));
            }
            h.set(px, y0 + 13, pz, b(Blocks.GOLD_BLOCK));
            h.set(px, y0 + 14, pz, b(Blocks.END_ROD));
        }
        // techo con ojo central
        for (int dx = -10; dx <= 10; dx++) {
            for (int dz = -10; dz <= 10; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d <= 10.4D && d >= 3.5D) {
                    h.set(cx + dx, y0 + 13, cz + dz, d > 8.5D ? b(Blocks.SMOOTH_QUARTZ) : b(Blocks.AMETHYST_BLOCK));
                }
                if (d <= 7.5D && d >= 4.5D) {
                    h.set(cx + dx, y0 + 14, cz + dz, b(Blocks.SMOOTH_QUARTZ));
                }
            }
        }
        // altar
        h.fill(cx - 2, y0 + 3, cz - 2, cx + 2, y0 + 3, cz + 2, b(Blocks.GOLD_BLOCK));
        h.fill(cx - 1, y0 + 4, cz - 1, cx + 1, y0 + 4, cz + 1, b(Blocks.CHISELED_QUARTZ_BLOCK));
        h.set(cx, y0 + 5, cz, b(Blocks.SEA_LANTERN));
        h.lootChest(cx, y0 + 3, cz - 6, this.loot(), random);
        h.lootChest(cx, y0 + 3, cz + 6, this.loot(), random);
        for (int[] c : new int[][]{{-6, -6}, {6, -6}, {-6, 6}, {6, 6}}) {
            h.set(cx + c[0], y0 + 3, cz + c[1], b(Blocks.LANTERN));
        }
        for (int[] w : new int[][]{{-4, 0}, {4, 0}, {0, 4}, {0, -4}, {-8, 8}, {8, -8}}) {
            this.worshipper(level, box, cx + w[0], y0 + 3, cz + w[1], rnd);
        }
    }

    // ---------------------------------------------------------------- aldea de adoradores

    private void village(BuildHelper h, WorldGenLevel level, BoundingBox box, Random rnd, RandomSource random) {
        int cx = this.cx;
        int cz = this.cz;
        int y0 = this.y0;
        for (int dx = -26; dx <= 26; dx++) {
            for (int dz = -26; dz <= 26; dz++) {
                h.foundation(cx + dx, cz + dz, y0, 10, b(Blocks.DIRT));
                if (Math.abs(dx) <= 26 && Math.abs(dz) <= 26) {
                    h.set(cx + dx, y0 - 1, cz + dz, b(Blocks.GRASS_BLOCK));
                }
            }
        }
        // plaza
        for (int dx = -6; dx <= 6; dx++) {
            for (int dz = -6; dz <= 6; dz++) {
                h.set(cx + dx, y0 - 1, cz + dz, (Math.abs(dx) + Math.abs(dz)) % 3 == 0 ? b(Blocks.POLISHED_ANDESITE) : b(Blocks.STONE_BRICKS));
            }
        }
        // totem del dragon
        h.fill(cx - 1, y0, cz - 1, cx + 1, y0, cz + 1, b(Blocks.MOSSY_STONE_BRICKS));
        for (int y = 1; y <= 8; y++) {
            h.set(cx, y0 + y, cz, y % 3 == 0 ? b(Blocks.CHISELED_STONE_BRICKS) : b(Blocks.MOSSY_STONE_BRICKS));
        }
        h.set(cx, y0 + 9, cz, b(Blocks.AMETHYST_BLOCK));
        h.set(cx, y0 + 10, cz, b(Blocks.END_ROD));
        for (int[] f : new int[][]{{-1, 0}, {1, 0}, {0, -1}, {0, 1}}) {
            h.set(cx + f[0] * 2, y0, cz + f[1] * 2, b(Blocks.LANTERN));
        }
        // cabanas
        int[][] huts = {{-16, -4}, {16, -4}, {-10, -17}, {10, -17}, {-10, 17}, {10, 17}};
        for (int i = 0; i < huts.length; i++) {
            this.hut(h, level, box, cx + huts[i][0], cz + huts[i][1], y0, huts[i][0], huts[i][1], rnd, random, i == 0);
        }
        for (int[] w : new int[][]{{3, 3}, {-3, 4}, {2, -4}, {-4, -3}}) {
            this.worshipper(level, box, cx + w[0], y0, cz + w[1], rnd);
        }
    }

    private void hut(BuildHelper h, WorldGenLevel level, BoundingBox box, int hx, int hz, int y0, int relX, int relZ,
                     Random rnd, RandomSource random, boolean chest) {
        // direccion de la puerta: hacia el centro de la aldea
        int doorDx = 0;
        int doorDz = 0;
        if (Math.abs(relX) >= Math.abs(relZ)) {
            doorDx = relX > 0 ? -1 : 1;
        } else {
            doorDz = relZ > 0 ? -1 : 1;
        }
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                h.set(hx + dx, y0 - 1, hz + dz, b(Blocks.COBBLESTONE));
                h.set(hx + dx, y0, hz + dz, b(Blocks.SPRUCE_PLANKS));
                for (int y = 1; y <= 4; y++) {
                    boolean edge = Math.abs(dx) == 3 || Math.abs(dz) == 3;
                    boolean corner = Math.abs(dx) == 3 && Math.abs(dz) == 3;
                    h.set(hx + dx, y0 + y, hz + dz, corner ? b(Blocks.STRIPPED_SPRUCE_LOG) : (edge ? b(Blocks.SPRUCE_PLANKS) : BuildHelper.AIR));
                }
            }
        }
        for (int dx = -4; dx <= 4; dx++) {
            for (int dz = -4; dz <= 4; dz++) {
                h.set(hx + dx, y0 + 5, hz + dz, b(Blocks.DARK_OAK_PLANKS));
                if (Math.abs(dx) <= 3 && Math.abs(dz) <= 3) {
                    h.set(hx + dx, y0 + 6, hz + dz, b(Blocks.DARK_OAK_PLANKS));
                }
                if (Math.abs(dx) <= 1 && Math.abs(dz) <= 1) {
                    h.set(hx + dx, y0 + 7, hz + dz, b(Blocks.DARK_OAK_PLANKS));
                }
            }
        }
        // puerta (hueco de 1x2) y ventanas
        h.fill(hx + doorDx * 3, y0 + 1, hz + doorDz * 3, hx + doorDx * 3, y0 + 2, hz + doorDz * 3, BuildHelper.AIR);
        h.set(hx - doorDx * 3, y0 + 2, hz - doorDz * 3, b(Blocks.GLASS_PANE));
        h.set(hx + doorDz * 3, y0 + 2, hz + doorDx * 3, b(Blocks.GLASS_PANE));
        h.set(hx - doorDz * 3, y0 + 2, hz - doorDx * 3, b(Blocks.GLASS_PANE));
        // interior
        h.set(hx, y0 + 4, hz, b(Blocks.LANTERN));
        h.fill(hx - 1, y0 + 1, hz - 1, hx + 1, y0 + 1, hz + 1, b(Blocks.RED_CARPET));
        h.set(hx - doorDx * 2, y0 + 1, hz - doorDz * 2, b(Blocks.CRAFTING_TABLE));
        if (chest) {
            h.lootChest(hx + doorDz * 2, y0 + 1, hz + doorDx * 2, this.loot(), random);
        }
        // camino hasta la plaza
        int px = hx + doorDx * 4;
        int pz = hz + doorDz * 4;
        for (int i = 0; i < 24; i++) {
            if (Math.abs(px - this.cx) <= 6 && Math.abs(pz - this.cz) <= 6) {
                break;
            }
            h.set(px, y0 - 1, pz, b(Blocks.GRAVEL));
            if (Math.abs(px - this.cx) > 6) {
                px += px > this.cx ? -1 : 1;
            } else {
                pz += pz > this.cz ? -1 : 1;
            }
        }
        this.worshipper(level, box, hx, y0 + 1, hz, rnd);
    }
}
