package com.isladragoncitos.worldgen;

import com.isladragoncitos.registry.ModStructures;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.NoiseColumn;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureType;

/** Castillos y cuevas gigantes: 0 fortaleza draconiana, 1 castillo elfico, 2 guarida del tesoro, 3 caverna de cristales. */
public class GiantStructure extends Structure {
    public static final Codec<GiantStructure> CODEC = RecordCodecBuilder.create(instance -> instance
            .group(settingsCodec(instance), Codec.INT.fieldOf("kind").forGetter(structure -> structure.kind))
            .apply(instance, GiantStructure::new));

    private final int kind;

    public GiantStructure(Structure.StructureSettings settings, int kind) {
        super(settings);
        this.kind = kind;
    }

    @Override
    public StructureType<?> type() {
        return ModStructures.GIANT_TYPE.get();
    }

    private int height(Structure.GenerationContext context, int x, int z) {
        return context.chunkGenerator().getFirstOccupiedHeight(x, z, Heightmap.Types.WORLD_SURFACE_WG,
                context.heightAccessor(), context.randomState());
    }

    @Override
    protected Optional<Structure.GenerationStub> findGenerationPoint(Structure.GenerationContext context) {
        ChunkPos chunk = context.chunkPos();
        int x = chunk.getMiddleBlockX();
        int z = chunk.getMiddleBlockZ();
        int h = this.height(context, x, z);
        NoiseColumn column = context.chunkGenerator().getBaseColumn(x, z, context.heightAccessor(), context.randomState());
        if (!column.getBlock(h - 1).getFluidState().isEmpty() || h < 63) {
            return Optional.empty();
        }
        boolean cave = this.kind >= GiantPiece.HOARD;
        if (cave) {
            if (h < 70 || h > 150) {
                return Optional.empty();
            }
        } else {
            int spread = this.kind == GiantPiece.CASTLE ? 40 : 34;
            int min = h;
            int max = h;
            int[][] offsets = {{spread, 0}, {-spread, 0}, {0, spread}, {0, -spread}, {spread, spread}, {-spread, -spread}};
            for (int[] o : offsets) {
                int other = this.height(context, x + o[0], z + o[1]);
                min = Math.min(min, other);
                max = Math.max(max, other);
            }
            if (max - min > 14) {
                return Optional.empty();
            }
        }
        long seed = context.random().nextLong();
        int rot = context.random().nextInt(4);
        int kind = this.kind;
        int surface = h;
        return Optional.of(new Structure.GenerationStub(new BlockPos(x, h, z),
                builder -> builder.addPiece(new GiantPiece(kind, x, surface, z, seed, rot))));
    }
}
