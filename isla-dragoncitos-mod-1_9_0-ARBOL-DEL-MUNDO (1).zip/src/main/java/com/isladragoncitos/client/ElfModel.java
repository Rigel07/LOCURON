package com.isladragoncitos.client;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.entity.ElfEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

/** Modelo humanoide del elfo: igual que un jugador, pero con orejas largas y puntiagudas. */
public class ElfModel extends HumanoidModel<ElfEntity> {
    public static final ModelLayerLocation LAYER_LOCATION =
            new ModelLayerLocation(new ResourceLocation(IslaDragoncitosMod.MODID, "elf"), "main");

    public ElfModel(ModelPart root) {
        super(root);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = HumanoidModel.createMesh(CubeDeformation.NONE, 0.0F);
        PartDefinition root = mesh.getRoot();
        PartDefinition head = root.getChild("head");
        head.addOrReplaceChild("left_ear", CubeListBuilder.create().texOffs(56, 16)
                        .addBox(0.0F, -1.0F, -0.5F, 3.0F, 2.0F, 1.0F),
                PartPose.offsetAndRotation(4.0F, -4.5F, 0.0F, 0.0F, 0.0F, -0.45F));
        head.addOrReplaceChild("right_ear", CubeListBuilder.create().texOffs(56, 16)
                        .addBox(-3.0F, -1.0F, -0.5F, 3.0F, 2.0F, 1.0F),
                PartPose.offsetAndRotation(-4.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.45F));
        return LayerDefinition.create(mesh, 64, 32);
    }
}
