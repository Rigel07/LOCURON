package com.isladragoncitos.client;

/** Colores del menu segun el tipo de dragon: 0 fuego, 1 hielo, 2 tormenta, 3 agua, 4 celeste. */
public record DragonTheme(String name, int accent, int light, int mid, int dark) {
    private static final DragonTheme[] THEMES = {
            new DragonTheme("Dragón de Fuego", 0xFFFF7A2E, 0xFFFFD27F, 0xFF4A1A0C, 0xFF200A05),
            new DragonTheme("Dragón de Hielo", 0xFF6FE0FF, 0xFFD8F6FF, 0xFF123A4F, 0xFF07161F),
            new DragonTheme("Dragón de Tormenta", 0xFFB98CFF, 0xFFFFE066, 0xFF2A1A52, 0xFF100820),
            new DragonTheme("Dragón del Agua", 0xFF47B6FF, 0xFFA8F0E8, 0xFF0E3566, 0xFF051326),
            new DragonTheme("Dragón Celeste", 0xFF8FFFE0, 0xFFF3D9FF, 0xFF1E1D5C, 0xFF0A0A26)
    };

    public static DragonTheme of(int type) {
        return THEMES[Math.max(0, Math.min(THEMES.length - 1, type))];
    }

    public static int mix(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }
}
