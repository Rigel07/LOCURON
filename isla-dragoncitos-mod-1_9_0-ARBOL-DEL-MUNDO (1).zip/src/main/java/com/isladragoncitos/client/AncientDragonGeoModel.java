package com.isladragoncitos.client;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.entity.AncientDragonEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import software.bernie.geckolib.constant.DataTickets;
import software.bernie.geckolib.core.animatable.model.CoreGeoBone;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.model.data.EntityModelData;

/** Modelo 3D de los dragones antiguos (fuego, hielo, tormenta, agua): geo + textura + animaciones de GeckoLib. */
public class AncientDragonGeoModel extends GeoModel<AncientDragonEntity> {
    /** Un nombre de modelo por tipo de dragon: 0 fuego, 1 hielo, 2 tormenta, 3 agua, 4 serpiente celeste. */
    public static final String[] NAMES = {"fire_dragon", "ice_dragon", "storm_dragon", "water_dragon", "sky_dragon"};

    private static String name(AncientDragonEntity dragon) {
        return NAMES[Mth.clamp(dragon.getDragonType(), 0, NAMES.length - 1)];
    }

    @Override
    public ResourceLocation getModelResource(AncientDragonEntity dragon) {
        return new ResourceLocation(IslaDragoncitosMod.MODID, "geo/entity/" + name(dragon) + ".geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(AncientDragonEntity dragon) {
        return new ResourceLocation(IslaDragoncitosMod.MODID, "textures/entity/" + name(dragon) + ".png");
    }

    @Override
    public ResourceLocation getAnimationResource(AncientDragonEntity dragon) {
        return new ResourceLocation(IslaDragoncitosMod.MODID, "animations/entity/" + name(dragon) + ".animation.json");
    }

    /** La cabeza sigue suavemente hacia donde mira el dragon. */
    @Override
    public void setCustomAnimations(AncientDragonEntity dragon, long instanceId, AnimationState<AncientDragonEntity> state) {
        super.setCustomAnimations(dragon, instanceId, state);
        CoreGeoBone head = this.getAnimationProcessor().getBone("head");
        EntityModelData data = state.getData(DataTickets.ENTITY_MODEL_DATA);
        if (head != null && data != null) {
            // GeckoLib entrega el giro sin normalizar: se acota para que la cabeza nunca de vueltas
            float pitch = Mth.clamp(Mth.wrapDegrees(data.headPitch()), -35.0F, 35.0F);
            float yaw = Mth.clamp(Mth.wrapDegrees(data.netHeadYaw()), -45.0F, 45.0F);
            head.setRotX(head.getRotX() + pitch * Mth.DEG_TO_RAD * 0.4F);
            head.setRotY(head.getRotY() + yaw * Mth.DEG_TO_RAD * 0.4F);
        }
    }
}
