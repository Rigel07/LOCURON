package com.isladragoncitos.client;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.network.DragonRequestPacket;
import com.isladragoncitos.network.ModNetwork;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = IslaDragoncitosMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientForgeEvents {
    private ClientForgeEvents() {}

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        Minecraft minecraft = Minecraft.getInstance();
        while (ModKeys.DRAGON_MENU.consumeClick()) {
            if (minecraft.player != null && minecraft.screen == null) {
                ModNetwork.CHANNEL.sendToServer(new DragonRequestPacket(DragonRequestPacket.OPEN, "", 0));
            }
        }
    }
}
