package com.isladragoncitos.block;

import com.isladragoncitos.entity.AncientDragonEntity;
import com.isladragoncitos.registry.ModBlockEntities;
import com.isladragoncitos.registry.ModEntities;
import com.isladragoncitos.system.DraconicData;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/** Incubacion del huevo: solo avanza cuando un jugador lo coloco; con calor cerca va mas deprisa. */
public class AncientEggBlockEntity extends BlockEntity {
    private static final int HATCH_TIME = 6000;

    @Nullable
    private UUID owner;
    private int progress;
    @Nullable
    private CompoundTag essence;

    public AncientEggBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.ANCIENT_EGG.get(), pos, state);
    }

    public boolean hasEssence() {
        return this.essence != null;
    }

    public void setEssence(CompoundTag essence) {
        this.essence = essence;
        this.setChanged();
    }

    @Nullable
    public CompoundTag takeEssence() {
        CompoundTag taken = this.essence;
        this.essence = null;
        this.setChanged();
        return taken;
    }

    public void setOwner(UUID owner) {
        this.owner = owner;
        this.setChanged();
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, AncientEggBlockEntity egg) {
        if (egg.owner == null || !(level instanceof ServerLevel serverLevel)) {
            return;
        }
        int rate = 1;
        for (BlockPos check : BlockPos.betweenClosed(pos.offset(-2, -1, -2), pos.offset(2, 1, 2))) {
            BlockState near = level.getBlockState(check);
            if (near.is(Blocks.FIRE) || near.is(Blocks.CAMPFIRE) || near.is(Blocks.SOUL_CAMPFIRE) || near.is(Blocks.LAVA)
                    || near.is(Blocks.MAGMA_BLOCK)) {
                rate = 4;
                break;
            }
        }
        egg.progress += rate;
        if (egg.progress % 40 == 0) {
            serverLevel.sendParticles(ParticleTypes.HAPPY_VILLAGER, pos.getX() + 0.5D, pos.getY() + 0.6D, pos.getZ() + 0.5D,
                    3, 0.2D, 0.2D, 0.2D, 0.0D);
            egg.setChanged();
        }
        if (egg.progress >= HATCH_TIME) {
            ServerPlayer player = serverLevel.getServer().getPlayerList().getPlayer(egg.owner);
            if (player == null) {
                egg.progress = HATCH_TIME;
                return;
            }
            egg.hatch(serverLevel, pos, state, player);
        }
    }

    private void hatch(ServerLevel level, BlockPos pos, BlockState state, ServerPlayer player) {
        int type = state.getBlock() instanceof AncientEggBlock egg ? egg.getDragonType() : 0;
        CompoundTag inserted = this.essence;
        this.essence = null;
        level.removeBlock(pos, false);
        AncientDragonEntity dragon = ModEntities.ANCIENT_DRAGON.get().create(level);
        if (dragon == null) {
            return;
        }
        dragon.moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, level.random.nextFloat() * 360.0F, 0.0F);
        dragon.setDragonType(type);
        String speciesId = com.isladragoncitos.entity.species.DragonSpecies.roll(type, new java.util.Random(level.random.nextLong()));
        dragon.setSpeciesId(speciesId);
        dragon.setFood(0);
        dragon.tame(player);
        if (inserted != null) {
            dragon.applyEssence(inserted);
        }
        dragon.setHealth(dragon.getMaxHealth());
        level.addFreshEntity(dragon);
        level.sendParticles(ParticleTypes.EXPLOSION, pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D, 3, 0.2D, 0.2D, 0.2D, 0.0D);
        level.playSound(null, pos, SoundEvents.ENDER_DRAGON_GROWL, SoundSource.NEUTRAL, 1.0F, 1.6F);
        DraconicData.setActiveDragon(player, dragon);
        DraconicData.discoverSpecies(player, speciesId);
        var born = com.isladragoncitos.entity.species.DragonSpecies.get(speciesId);
        if (born != null) {
            player.displayClientMessage(net.minecraft.network.chat.Component.literal("\u00a76\u00a1Ha nacido: \u00a7f" + born.name
                    + " \u00a77(" + born.element.nameEs + ", " + born.rarity.nameEs + ")"), false);
        }
        DraconicData.onHatch(player, dragon.getUUID(), type);
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putInt("Progress", this.progress);
        if (this.essence != null) {
            tag.put("Essence", this.essence.copy());
        }
        if (this.owner != null) {
            tag.putUUID("Owner", this.owner);
        }
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        this.progress = tag.getInt("Progress");
        this.essence = tag.contains("Essence") ? tag.getCompound("Essence") : null;
        this.owner = tag.hasUUID("Owner") ? tag.getUUID("Owner") : null;
    }
}
