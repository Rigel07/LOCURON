package com.isladragoncitos.item;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/** Amuleto de escama: mientras lo llevas en el inventario te da dos efectos permanentes. */
public class AmuletItem extends Item {
    private final MobEffect effectA;
    private final MobEffect effectB;
    private final String tooltipKey;

    public AmuletItem(Properties properties, MobEffect effectA, MobEffect effectB, String tooltipKey) {
        super(properties);
        this.effectA = effectA;
        this.effectB = effectB;
        this.tooltipKey = tooltipKey;
    }

    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        if (!level.isClientSide && entity instanceof Player player && player.tickCount % 40 == 0) {
            int amp = com.isladragoncitos.system.DraconicData.hasMark(player) ? 1 : 0;
            player.addEffect(new MobEffectInstance(this.effectA, 120, amp, true, false, true));
            player.addEffect(new MobEffectInstance(this.effectB, 120, amp, true, false, true));
        }
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable(this.tooltipKey).withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.isladragoncitos.amulet").withStyle(ChatFormatting.DARK_GRAY));
    }
}
