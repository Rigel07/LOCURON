package com.isladragoncitos.item;

import com.isladragoncitos.abilities.DraconicAbilities;
import com.isladragoncitos.registry.ModItems;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/**
 * Manuscrito Draconiano: contiene una habilidad. Un jinete (con la Marca del Jinete) la aprende al leerlo
 * gastando puntos draconianos. Sin habilidad guardada, al leerlo se descubre una al azar.
 */
public class DraconicManuscriptItem extends Item {
    public DraconicManuscriptItem(Properties properties) {
        super(properties);
    }

    public static ItemStack of(String abilityId) {
        ItemStack stack = new ItemStack(ModItems.DRACONIC_MANUSCRIPT.get());
        stack.getOrCreateTag().putString("Ability", abilityId);
        return stack;
    }

    public static String abilityOf(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        return tag == null ? "" : tag.getString("Ability");
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide || !(player instanceof ServerPlayer server)) {
            return InteractionResultHolder.success(stack);
        }
        String id = abilityOf(stack);
        if (!DraconicAbilities.exists(id)) {
            List<String> ids = DraconicAbilities.ids();
            id = ids.get(level.random.nextInt(ids.size()));
            stack.getOrCreateTag().putString("Ability", id);
        }
        if (DraconicAbilities.learn(server, id) && !player.getAbilities().instabuild) {
            stack.shrink(1);
        }
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public Component getName(ItemStack stack) {
        DraconicAbilities.Ability ability = DraconicAbilities.get(abilityOf(stack));
        if (ability == null) {
            return super.getName(stack);
        }
        return Component.translatable("item.isladragoncitos.draconic_manuscript").append(": " + ability.nameEs);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        DraconicAbilities.Ability ability = DraconicAbilities.get(abilityOf(stack));
        if (ability == null) {
            tooltip.add(Component.translatable("tooltip.isladragoncitos.manuscript.random").withStyle(ChatFormatting.GRAY));
        } else {
            tooltip.add(Component.literal(ability.descEs).withStyle(ChatFormatting.GRAY));
            tooltip.add(Component.literal(ability.costPoints + " puntos draconianos \u00b7 recarga " + ability.cooldownSec + " s")
                    .withStyle(ChatFormatting.GOLD));
        }
        tooltip.add(Component.translatable("tooltip.isladragoncitos.manuscript.riders").withStyle(ChatFormatting.DARK_GRAY));
    }
}
