package com.isladragoncitos.item;

import com.isladragoncitos.network.CodexPacket;
import com.isladragoncitos.network.ModNetwork;
import com.isladragoncitos.system.DraconicData;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/** Codice Draconico: enciclopedia interactiva de todas las especies de dragon. */
public class DragonCodexItem extends Item {
    public DragonCodexItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer server) {
            ModNetwork.sendTo(server, new CodexPacket(new ArrayList<>(DraconicData.getDiscoveredSpecies(server)), player.getAbilities().instabuild));
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.isladragoncitos.codex").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.isladragoncitos.codex.use").withStyle(ChatFormatting.DARK_GRAY));
    }
}
